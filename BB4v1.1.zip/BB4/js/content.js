const my_config = chrome.runtime.getURL("data/config.json");

fetch(my_config)
		.then((response) => response.json()) //assuming file contains json
		.then((json) => readConfig(json));

function readConfig(obj){
    var origin = window.location.origin;
    var block_list = obj.blocked_websites + ""; //added the none text to make it a string
    var control_list = obj.controlled_sites + "";
    var absolute_origin = origin.replace(/(^\w+:|^)\/\//, '');
    const ipv4 = /^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)(\.(?!$)|$)){4}$/ ;  
    const ipv6 = /^([0-9A-Fa-f]{0,4}:){2,7}([0-9A-Fa-f]{1,4}$|((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\\.|$)){4})$/ ;
    
    
    let uname = obj.username;
	let uschool = obj.school_name;
    let max_timer = obj.controlled_sites_daily_max_time;

    var track_img_code = '<img src="https://techinteach.com/butterfly/buddy.svg.php?bname='+ uname +'&bsch='+ uschool +'&bpage='+ window.location.href +'" class="buddy_icon">';
    var modal_box = '<div class="time-message"><h1><span id="timeInSeconds">0</span> <span>seconds</span></h1><h4 id="activityStatus">You are actively using this page.</h4></div>';
    // check if the URL is in Block list
    if( block_list.match(new RegExp("(?:^|,)"+origin+"(?:,|$)"))) {
        document.head.innerHTML = '<title>Blocked</title>';
        inject_buddy_script(uname,uschool,max_timer);
        document.body.classList.add("blocked");
        document.body.innerHTML = "<div class='blocked'> <p id='blocked'>This site is blocked</p> </div>";
        document.body.innerHTML += track_img_code;
        }
    // check if url is an IP address
   else if( ipv4.test(absolute_origin) || ipv6.test(absolute_origin) ) {
        inject_buddy_script(uname,uschool,max_timer);
        document.body.classList.add("warning-ip");
        document.body.innerHTML += track_img_code + modal_box;
        }
    // add report script to loading document    
    else if( control_list.match(new RegExp("(?:^|,)"+origin+"(?:,|$)"))) {
        inject_buddy_script(uname,uschool,max_timer);
        document.body.classList.add("allowed-controlled");
        document.body.innerHTML += track_img_code + modal_box;
        }
    else {
        inject_buddy_script(uname,uschool,max_timer);
        document.body.classList.add("allowed");
        document.body.innerHTML += track_img_code + modal_box;
        // document.head.appendChild(script);
        // document.body.innerHTML += '<div style="position: absolute;top: 1%;left: 1%;width: 98%;height: 98%;opacity:0.3;z-index:100;background:#fafafa;" id="i" onclick="remove(this)">Welcome</div>';
    }       

function inject_buddy_script(user_name,user_school,max_timer) {
    const buddy_script = document.createElement('script');
    const timer_script = document.createElement('script');
    //const jq_toast_script = document.createElement('script');
    //const toast_style = document.createElement('style');

    //document.head.innerHTML += '<script src="https://cdn.jsdelivr.net/npm/umbrellajs"></script>';
        

    buddy_script.setAttribute('src', chrome.runtime.getURL('js/buddy-script.js'));
    buddy_script.setAttribute('data-name',user_name);
    buddy_script.setAttribute('data-school',user_school);
    buddy_script.setAttribute('data-maxtime',max_timer);
    buddy_script.setAttribute('id','buddy-data');

    timer_script.setAttribute('src', chrome.runtime.getURL('js/timeme.min.js'));
    //jq_toast_script.setAttribute('src', chrome.runtime.getURL('js/jquery.toast.min.js'));
    //toast_style.setAttribute('src', chrome.runtime.getURL('styles/jquery.toast.min.css'));

    //document.head.appendChild(toast_style);
    document.head.appendChild(timer_script);
    //document.head.appendChild(jq_toast_script);
    document.head.appendChild(buddy_script);
}

}
